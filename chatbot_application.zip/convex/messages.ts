import { v } from "convex/values";
import { query, mutation, internalAction, internalMutation, internalQuery } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api, internal } from "./_generated/api";

export const list = query({
  args: {
    chatId: v.id("chats"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    // Verify user owns the chat
    const chat = await ctx.db.get(args.chatId);
    if (!chat || chat.userId !== userId) {
      throw new Error("Chat not found or access denied");
    }

    return await ctx.db
      .query("messages")
      .withIndex("by_chat", (q) => q.eq("chatId", args.chatId))
      .order("asc")
      .collect();
  },
});

export const send = mutation({
  args: {
    chatId: v.id("chats"),
    content: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    // Verify user owns the chat
    const chat = await ctx.db.get(args.chatId);
    if (!chat || chat.userId !== userId) {
      throw new Error("Chat not found or access denied");
    }

    // Insert user message
    const messageId = await ctx.db.insert("messages", {
      chatId: args.chatId,
      content: args.content,
      role: "user",
      userId,
    });

    // Save question to history (only save the first message of each chat)
    const existingMessages = await ctx.db
      .query("messages")
      .withIndex("by_chat", (q) => q.eq("chatId", args.chatId))
      .collect();
    
    if (existingMessages.length === 1) { // This is the first message
      await ctx.runMutation(api.questions.create, {
        question: args.content,
        chatId: args.chatId,
      });
    }

    // Schedule AI response
    await ctx.scheduler.runAfter(0, internal.messages.generateResponse, {
      chatId: args.chatId,
      userMessage: args.content,
    });

    return messageId;
  },
});

export const generateResponse = internalAction({
  args: {
    chatId: v.id("chats"),
    userMessage: v.string(),
  },
  handler: async (ctx, args) => {
    // Get chat history for context
    const messages: any = await ctx.runQuery(internal.messages.getMessagesForChat, {
      chatId: args.chatId,
    });

    // Prepare conversation history
    const conversationHistory: any = messages.map((msg: any) => ({
      role: msg.role,
      content: msg.content,
    }));

    // Call OpenRouter API with DeepSeek model
    const response: any = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer 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`,
        "Content-Type": "application/json",
        "HTTP-Referer": "https://convex.dev",
        "X-Title": "AI Chatbot"
      },
      body: JSON.stringify({
        model: "deepseek/deepseek-chat-v3-0324:free",
        messages: [
          {
            role: "system",
            content: "You are a helpful AI assistant. Provide concise and helpful responses.",
          },
          ...conversationHistory,
        ],
        max_tokens: 500,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`OpenRouter API error: ${response.statusText} - ${errorText}`);
    }

    const data: any = await response.json();
    const aiResponse: any = data.choices[0]?.message?.content;

    if (!aiResponse) {
      throw new Error("No response from AI");
    }

    // Save AI response to database
    await ctx.runMutation(internal.messages.saveAiResponse, {
      chatId: args.chatId,
      content: aiResponse,
    });

    return aiResponse;
  },
});

export const getMessagesForChat = internalQuery({
  args: {
    chatId: v.id("chats"),
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("messages")
      .withIndex("by_chat", (q) => q.eq("chatId", args.chatId))
      .order("asc")
      .collect();
  },
});

export const saveAiResponse = internalMutation({
  args: {
    chatId: v.id("chats"),
    content: v.string(),
  },
  handler: async (ctx, args) => {
    // Get the chat to find the owner
    const chat = await ctx.db.get(args.chatId);
    if (!chat) {
      throw new Error("Chat not found");
    }

    return await ctx.db.insert("messages", {
      chatId: args.chatId,
      content: args.content,
      role: "assistant",
      userId: chat.userId,
    });
  },
});
