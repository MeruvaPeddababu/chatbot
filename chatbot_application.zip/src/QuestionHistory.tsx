import { useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { Id } from "../convex/_generated/dataModel";

interface Question {
  _id: Id<"questions">;
  question: string;
  chatId: Id<"chats">;
  _creationTime: number;
}

interface QuestionHistoryProps {
  onSelectChat: (chatId: Id<"chats">) => void;
  selectedChatId: Id<"chats"> | null;
}

export function QuestionHistory({ onSelectChat, selectedChatId }: QuestionHistoryProps) {
  const questions = useQuery(api.questions.list) || [];

  const truncateQuestion = (question: string, maxLength: number = 60) => {
    if (question.length <= maxLength) return question;
    return question.substring(0, maxLength) + "...";
  };

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffInDays === 0) {
      return "Today";
    } else if (diffInDays === 1) {
      return "Yesterday";
    } else if (diffInDays < 7) {
      return `${diffInDays} days ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  // Group questions by date
  const groupedQuestions = questions.reduce((groups: { [key: string]: Question[] }, question) => {
    const dateKey = formatDate(question._creationTime);
    if (!groups[dateKey]) {
      groups[dateKey] = [];
    }
    groups[dateKey].push(question);
    return groups;
  }, {});

  return (
    <div className="flex-1 overflow-y-auto">
      {questions.length === 0 ? (
        <div className="p-4 text-gray-500 text-center">
          <div className="mb-2">📝</div>
          <p className="text-sm">Your question history will appear here</p>
        </div>
      ) : (
        <div className="p-2">
          {Object.entries(groupedQuestions).map(([dateGroup, questionsInGroup]) => (
            <div key={dateGroup} className="mb-4">
              <div className="px-2 py-1 text-xs font-semibold text-gray-500 uppercase tracking-wide">
                {dateGroup}
              </div>
              {questionsInGroup.map((question) => (
                <button
                  key={question._id}
                  onClick={() => onSelectChat(question.chatId)}
                  className={`w-full text-left p-3 rounded-lg mb-1 transition-colors group ${
                    selectedChatId === question.chatId
                      ? "bg-primary text-white"
                      : "hover:bg-gray-100"
                  }`}
                >
                  <div className="flex items-start gap-2">
                    <div className="flex-shrink-0 mt-1">
                      <div className={`w-2 h-2 rounded-full ${
                        selectedChatId === question.chatId ? "bg-white" : "bg-gray-400"
                      }`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm leading-tight">
                        {truncateQuestion(question.question)}
                      </div>
                      <div className={`text-xs mt-1 ${
                        selectedChatId === question.chatId ? "text-white/70" : "text-gray-500"
                      }`}>
                        {new Date(question._creationTime).toLocaleTimeString([], { 
                          hour: '2-digit', 
                          minute: '2-digit' 
                        })}
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
