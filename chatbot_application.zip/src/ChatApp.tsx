import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { Id } from "../convex/_generated/dataModel";
import { ChatList } from "./ChatList";
import { ChatView } from "./ChatView";
import { QuestionHistory } from "./QuestionHistory";

export function ChatApp() {
  const [selectedChatId, setSelectedChatId] = useState<Id<"chats"> | null>(null);
  const [showNewChatForm, setShowNewChatForm] = useState(false);
  const [newChatTitle, setNewChatTitle] = useState("");
  const [activeTab, setActiveTab] = useState<"chats" | "history">("history");

  const chats = useQuery(api.chats.list) || [];
  const createChat = useMutation(api.chats.create);

  const handleCreateChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChatTitle.trim()) return;

    const chatId = await createChat({ title: newChatTitle });
    setSelectedChatId(chatId);
    setNewChatTitle("");
    setShowNewChatForm(false);
    setActiveTab("chats");
  };

  return (
    <div className="flex h-full">
      {/* Sidebar */}
      <div className="w-80 bg-white border-r border-gray-200 flex flex-col">
        <div className="p-4 border-b border-gray-200">
          <button
            onClick={() => setShowNewChatForm(true)}
            className="w-full px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-hover transition-colors mb-3"
          >
            + New Chat
          </button>
          
          {/* Tab Navigation */}
          <div className="flex bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setActiveTab("history")}
              className={`flex-1 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                activeTab === "history"
                  ? "bg-white text-primary shadow-sm"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              History
            </button>
            <button
              onClick={() => setActiveTab("chats")}
              className={`flex-1 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                activeTab === "chats"
                  ? "bg-white text-primary shadow-sm"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              Chats
            </button>
          </div>
        </div>

        {showNewChatForm && (
          <div className="p-4 border-b border-gray-200 bg-gray-50">
            <form onSubmit={handleCreateChat}>
              <input
                type="text"
                value={newChatTitle}
                onChange={(e) => setNewChatTitle(e.target.value)}
                placeholder="Chat title..."
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                autoFocus
              />
              <div className="flex gap-2 mt-2">
                <button
                  type="submit"
                  className="px-3 py-1 bg-primary text-white rounded text-sm hover:bg-primary-hover"
                >
                  Create
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowNewChatForm(false);
                    setNewChatTitle("");
                  }}
                  className="px-3 py-1 bg-gray-300 text-gray-700 rounded text-sm hover:bg-gray-400"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Tab Content */}
        {activeTab === "history" ? (
          <QuestionHistory 
            onSelectChat={setSelectedChatId}
            selectedChatId={selectedChatId}
          />
        ) : (
          <ChatList
            chats={chats}
            selectedChatId={selectedChatId}
            onSelectChat={setSelectedChatId}
          />
        )}
      </div>

      {/* Main Chat Area */}
      <div className="flex-1">
        {selectedChatId ? (
          <ChatView chatId={selectedChatId} />
        ) : (
          <div className="flex items-center justify-center h-full text-gray-500">
            <div className="text-center">
              <div className="text-6xl mb-4">💬</div>
              <h2 className="text-2xl font-semibold mb-2">Welcome to AI Chatbot</h2>
              <p className="mb-4">Your questions and conversations are automatically saved</p>
              <div className="text-sm text-gray-400">
                <p>• Browse your question history in the sidebar</p>
                <p>• Click on any question to continue the conversation</p>
                <p>• Create new chats for different topics</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
