import { Id } from "../convex/_generated/dataModel";

interface Chat {
  _id: Id<"chats">;
  title: string;
  _creationTime: number;
}

interface ChatListProps {
  chats: Chat[];
  selectedChatId: Id<"chats"> | null;
  onSelectChat: (chatId: Id<"chats">) => void;
}

export function ChatList({ chats, selectedChatId, onSelectChat }: ChatListProps) {
  return (
    <div className="flex-1 overflow-y-auto">
      {chats.length === 0 ? (
        <div className="p-4 text-gray-500 text-center">
          No chats yet. Create your first chat!
        </div>
      ) : (
        <div className="p-2">
          {chats.map((chat) => (
            <button
              key={chat._id}
              onClick={() => onSelectChat(chat._id)}
              className={`w-full text-left p-3 rounded-lg mb-2 transition-colors ${
                selectedChatId === chat._id
                  ? "bg-primary text-white"
                  : "hover:bg-gray-100"
              }`}
            >
              <div className="font-medium truncate">{chat.title}</div>
              <div className="text-sm opacity-70">
                {new Date(chat._creationTime).toLocaleDateString()}
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
